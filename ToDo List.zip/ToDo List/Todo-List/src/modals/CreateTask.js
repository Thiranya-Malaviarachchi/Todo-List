import React, { useState } from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

const CreateTaskPopup = ({modal, toggle, save}) => {
    const [taskName, setTaskName] = useState('');
    const [enddate, setEndDate] = useState('');
    const [state, setState] = useState('');

    const handleChange = (e) => {
        
        const {name, value,status,endDate} = e.target

        if(name === "taskName"){
            setTaskName(value)
        }else if(endDate === "enddate"){
            setEndDate(value)
        }else if(status === "state"){
            setState(value)
        }


    }

    const handleSave = (e) => {
        e.preventDefault()
        let taskObj = {}
        taskObj["Name"] = taskName
        taskObj["EndDate"] = enddate
        taskObj["State"] = state
        save(taskObj)

    }

    return (
        <Modal isOpen={modal} toggle={toggle}>
            <ModalHeader toggle={toggle}>Create Task</ModalHeader>
            <ModalBody>
            
                    <div className = "form-group">
                        <label>Task Name</label>
                        <input type="text" className = "form-control" value = {taskName} onChange = {handleChange} name = "taskName"/>
                    </div>
                    <div className = "form-group">
                        <label>State</label>
                        <input type="text" className = "form-control" value = {enddate} onChange = {handleChange} name = "enddate"/>
                        
                    </div>
                    <div className = "form-group">
                        <label>End Date</label>
                        <input type="text" className = "form-control" value = {state} onChange = {handleChange} name = "state"/>
                        
                    </div>
                
            </ModalBody>
            <ModalFooter>
            <Button color="primary" onClick={handleSave}>Create</Button>{' '}
            <Button color="secondary" onClick={toggle}>Cancel</Button>
            </ModalFooter>
      </Modal>
    );
};

export default CreateTaskPopup;